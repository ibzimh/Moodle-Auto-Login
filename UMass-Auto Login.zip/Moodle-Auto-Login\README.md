# Umass-Auto-Login    

Automatically press the log-in button on Spire, Canvas, Moodle etc.